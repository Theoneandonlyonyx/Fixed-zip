package net.mikexxx.pmpport;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.BonemealableBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Bamboo of the original mod (1.12.2 BlockPlantBamboo, 1.7.10 STALK growth): a stalk that can be stacked block on block
 * (like vanilla bamboo / sugar cane) and grows upwards by itself. SEGMENT 0..3 = stalk pieces from the ground up, 4 = leafy top.
 * Every species has its own height (1.7.10 "gmax"); each stand gets its own limit between about 65 % and 100 % of it.
 */
public class BambooStalkBlock extends Block implements BonemealableBlock {
    public static final IntegerProperty SEGMENT = IntegerProperty.create("segment", 0, 4);
    public static final BooleanProperty WAXED = BooleanProperty.create("waxed");
    private static final VoxelShape SHAPE = Block.box(5, 0, 5, 11, 16, 11);

    private final int maxHeight;

    public BambooStalkBlock(Properties props, int maxHeight) {
        super(props);
        this.maxHeight = maxHeight;
        this.registerDefaultState(this.stateDefinition.any().setValue(SEGMENT, 4).setValue(WAXED, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
        b.add(SEGMENT, WAXED);
    }

    @Override
    public VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
        return SHAPE;
    }

    private static boolean isBamboo(BlockState s) {
        return s.getBlock() instanceof BambooStalkBlock;
    }

    // ---------------------------------------------------------------- placement / support

    @Override
    public boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        BlockState below = level.getBlockState(pos.below());
        return isBamboo(below) || below.is(BlockTags.DIRT) || below.is(BlockTags.SAND)
                || below.getBlock() instanceof PlanterBlock || below.getBlock() instanceof ShapedBlock;
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        BlockState s = this.defaultBlockState();
        return s.canSurvive(ctx.getLevel(), ctx.getClickedPos()) ? s.setValue(SEGMENT, expected(ctx.getLevel(), ctx.getClickedPos())) : null;
    }

    /** segment from the neighbours: leafy top (4) when nothing is above, otherwise 0 at the ground and 1..3 further up */
    private static int expected(LevelReader level, BlockPos p) {
        if (!isBamboo(level.getBlockState(p.above()))) return 4;
        BlockState below = level.getBlockState(p.below());
        if (isBamboo(below)) {
            int s = below.getValue(SEGMENT);
            return Math.min(s >= 4 ? 3 : s + 1, 3);
        }
        return 0;
    }

    @Override
    public BlockState updateShape(BlockState s, Direction d, BlockState n, LevelAccessor l, BlockPos p, BlockPos np) {
        if (!s.canSurvive(l, p)) l.scheduleTick(p, this, 1);              // like sugar cane: breaks and drops later
        if (d.getAxis() == Direction.Axis.Y) {
            int e = expected(l, p);
            if (e != s.getValue(SEGMENT)) return s.setValue(SEGMENT, e);
        }
        return s;
    }

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (!state.canSurvive(level, pos)) level.destroyBlock(pos, true);
    }

    // ---------------------------------------------------------------- growth

    private BlockPos bottomOf(LevelReader level, BlockPos pos) {
        BlockPos p = pos;
        while (isBamboo(level.getBlockState(p.below()))) p = p.below();
        return p;
    }

    private BlockPos topOf(LevelReader level, BlockPos pos) {
        BlockPos p = pos;
        while (isBamboo(level.getBlockState(p.above()))) p = p.above();
        return p;
    }

    /** height limit of THIS stand: the species maximum, scaled to 65..100 % by the position of its lowest block */
    private int limitFor(BlockPos bottom) {
        long h = bottom.asLong() * 0x9E3779B97F4A7C15L;
        h ^= (h >>> 29);
        double f = ((h & 1023L) / 1023.0D);
        return Math.max(2, (int) Math.round(maxHeight * (0.65D + 0.35D * f)));
    }

    private boolean canGrow(LevelReader level, BlockPos pos) {
        BlockPos bottom = bottomOf(level, pos), top = topOf(level, pos);
        if (level.getBlockState(bottom).getValue(WAXED)) return false;
        int height = top.getY() - bottom.getY() + 1;
        return height < limitFor(bottom) && level.getBlockState(top.above()).isAir();
    }

    private void growOne(Level level, BlockPos pos) {
        BlockPos top = topOf(level, pos);
        BlockPos up = top.above();
        BlockState st = level.getBlockState(top);
        BlockState ns = this.defaultBlockState().setValue(WAXED, false);
        if (ns.canSurvive(level, up) && level.getBlockState(up).isAir()) {
            level.setBlock(up, ns, 3);
            level.setBlock(top, level.getBlockState(top).setValue(SEGMENT, expected(level, top)), 2);
        }
    }

    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (isBamboo(level.getBlockState(pos.below()))) return;           // only the lowest block drives growth
        if (level.getRawBrightness(pos.above(), 0) >= 9 && random.nextInt(3) == 0 && canGrow(level, pos)) growOne(level, pos);
    }

    @Override
    public boolean isValidBonemealTarget(LevelReader level, BlockPos pos, BlockState state, boolean client) {
        return canGrow(level, pos);
    }

    @Override
    public boolean isBonemealSuccess(Level level, RandomSource r, BlockPos pos, BlockState state) {
        return true;
    }

    @Override
    public void performBonemeal(ServerLevel level, RandomSource r, BlockPos pos, BlockState state) {
        int n = 1 + r.nextInt(2);
        for (int i = 0; i < n && canGrow(level, pos); i++) growOne(level, pos);
    }

    // ---------------------------------------------------------------- waxing

    private void setWax(Level level, BlockPos pos, boolean wax) {
        BlockPos p = bottomOf(level, pos);
        while (isBamboo(level.getBlockState(p))) {
            level.setBlock(p, level.getBlockState(p).setValue(WAXED, wax), 2);
            p = p.above();
        }
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemStack held = player.getItemInHand(hand);
        boolean waxed = state.getValue(WAXED);
        if (held.is(Items.HONEYCOMB) && !waxed) {
            if (!level.isClientSide) {
                setWax(level, pos, true);
                level.levelEvent(null, 3003, pos, 0);
                if (!player.getAbilities().instabuild) held.shrink(1);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (held.getItem() instanceof AxeItem && waxed) {
            if (!level.isClientSide) {
                setWax(level, pos, false);
                level.levelEvent(null, 3004, pos, 0);
                held.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        return InteractionResult.PASS;
    }
}
